/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./constants.js":
/*!**********************!*\
  !*** ./constants.js ***!
  \**********************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nexports.DYNAMODB_TABLE_NAME = \"\";\nexports.ENTITY_TYPES = {\n  USER: \"User\",\n  COURSE: \"Course\",\n  COURSE_SUBSCRIPTION: \"CourseSubscription\",\n  COURSE_VIDEO: \"CourseVideo\",\n  COMMENT: \"Comment\"\n};\nexports.OPERATION = {\n  INSERT: \"INSERT\",\n  UPDATE: \"UPDATE\"\n};\nexports.DYNAMO_EVENTS = {\n  INSERT: \"INSERT\"\n};\nexports.EMAIL_TYPES = {\n  SUBSCRIPTION: \"SUBSCRIPTION\"\n};\n\n//# sourceURL=webpack://online-course/./constants.js?");

/***/ }),

/***/ "./helper/dynamodb-helper.js":
/*!***********************************!*\
  !*** ./helper/dynamodb-helper.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _awsSdk = __webpack_require__(/*! aws-sdk */ \"aws-sdk\");\n\nvar _awsSdk2 = _interopRequireDefault(_awsSdk);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass DynamoDBHelper {\n  constructor() {\n    this.dynamodb = new _awsSdk2.default.DynamoDB.DocumentClient();\n    this.tableName = \"onlineCourse\";\n  }\n\n  async getEntityById(entityType, id) {\n    if (!id) return null;\n    const params = {\n      TableName: this.tableName,\n      Key: {\n        entityType,\n        id\n      }\n    };\n    const item = await this.dynamodb.get(params).promise();\n    return item && Object.keys(item).length > 0 && item.Item;\n  }\n\n  async getEntityByGsi1(entityType, gsi1) {\n    const params = {\n      TableName: this.tableName,\n      IndexName: \"entity-gsi1-index\",\n      KeyConditionExpression: \"entityType = :entityType and gsi1 = :gsi1\",\n      ExpressionAttributeValues: {\n        \":entityType\": entityType,\n        \":gsi1\": gsi1\n      }\n    };\n    const result = await this.dynamodb.query(params).promise();\n    return result.Items;\n  }\n\n  async getEntityByGsi2(entityType, gsi2) {\n    const params = {\n      TableName: this.tableName,\n      IndexName: \"entity-gsi2-index\",\n      KeyConditionExpression: \"entityType = :entityType and gsi2 = :gsi2\",\n      ExpressionAttributeValues: {\n        \":entityType\": entityType,\n        \":gsi2\": gsi2\n      }\n    };\n    const result = await this.dynamodb.query(params).promise();\n    return result.Items;\n  }\n\n  async batchWrite(items) {\n    const params = {\n      RequestItems: {\n        [this.tableName]: items.map(item => ({\n          PutRequest: {\n            Item: item\n          }\n        }))\n      }\n    };\n    console.log(`batchWrite::`, JSON.stringify(params, 0, 2));\n    return this.dynamodb.batchWrite(params).promise();\n  }\n\n  async batchDelete(items) {\n    const params = {\n      RequestItems: {\n        [this.tableName]: items.map(item => ({\n          DeleteRequest: {\n            Key: item\n          }\n        }))\n      }\n    };\n    console.log(`batchWrite::`, JSON.stringify(params, 0, 2));\n    const response = await this.dynamodb.batchWrite(params).promise();\n    return await this.verifyUnProcessedData(response);\n  }\n\n  async verifyUnProcessedData(response) {\n    try {\n      console.log(`verifyUnProcessedData:: `, JSON.stringify(response, 0, 2));\n      const unProcessedData = response.UnprocessedItems[this.tableName] || [];\n      if (!unProcessedData.length) return response;\n      const requestPromises = [];\n      const params = {\n        RequestItems: {\n          [this.tableName]: unProcessedData\n        }\n      };\n      requestPromises.push(this.dynamodb.batchWrite(params).promise());\n      const resp = await Promise.all(requestPromises);\n      return verifyUnProcessedData(resp, dynamoHelper);\n    } catch (error) {\n      throw error;\n    }\n  }\n\n}\n\nexports.default = DynamoDBHelper;\n\n//# sourceURL=webpack://online-course/./helper/dynamodb-helper.js?");

/***/ }),

/***/ "./helper/s3-helper.js":
/*!*****************************!*\
  !*** ./helper/s3-helper.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _awsSdk = __webpack_require__(/*! aws-sdk */ \"aws-sdk\");\n\nvar _awsSdk2 = _interopRequireDefault(_awsSdk);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass S3Helper {\n  constructor() {\n    this.s3 = new _awsSdk2.default.S3({\n      apiVersion: \"2006-03-01\"\n    });\n  }\n\n  deleteObjects(keys) {\n    if (!keys.length) return;\n    const params = {\n      Bucket: \"online-course-content\",\n      Delete: {\n        Objects: keys.map(key => ({\n          Key: `public/${key}`\n        })),\n        Quiet: false\n      }\n    };\n    return this.s3.deleteObjects(params).promise();\n  }\n\n}\n\nexports.default = S3Helper;\n\n//# sourceURL=webpack://online-course/./helper/s3-helper.js?");

/***/ }),

/***/ "./lambdas/mutations.js":
/*!******************************!*\
  !*** ./lambdas/mutations.js ***!
  \******************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\n\nvar _functionsRegistry = __webpack_require__(/*! ../mutations/functions-registry */ \"./mutations/functions-registry.js\");\n\nvar _functionsRegistry2 = _interopRequireDefault(_functionsRegistry);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nasync function invokeHandler(event, registry, isMainHandler) {\n  console.log(`Invoke handler`, registry);\n  const result = await registry.mutationHandler(event);\n  if (isMainHandler) event.returnValue = result;else event.prevResult = result;\n\n  const postMutationHandler = registry.postMutationHandler && _functionsRegistry2.default.find(f => f.name === registry.postMutationHandler);\n\n  if (postMutationHandler) {\n    return invokeHandler(event, postMutationHandler);\n  }\n\n  return;\n}\n\nmodule.exports.handler = async (event, context, callback) => {\n  try {\n    console.log(`EVENT:: `, JSON.stringify(event, 0, 2));\n    const {\n      mutationName,\n      args,\n      user\n    } = event;\n\n    const handler = _functionsRegistry2.default.find(f => f.name === mutationName);\n\n    if (handler) {\n      await invokeHandler(event, handler, true);\n    }\n\n    callback(null, event.returnValue);\n  } catch (error) {\n    console.error(error);\n    throw error;\n  }\n};\n\n//# sourceURL=webpack://online-course/./lambdas/mutations.js?");

/***/ }),

/***/ "./models/base-model.js":
/*!******************************!*\
  !*** ./models/base-model.js ***!
  \******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _moment = __webpack_require__(/*! moment */ \"moment\");\n\nvar _moment2 = _interopRequireDefault(_moment);\n\nvar _uuid = __webpack_require__(/*! uuid */ \"uuid\");\n\nvar _constants = __webpack_require__(/*! ../constants */ \"./constants.js\");\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass BaseModel {\n  constructor(data, user, operation) {\n    this.user = user;\n    this.data = data;\n    this.operation = operation;\n\n    if (this.operation === _constants.OPERATION.INSERT) {\n      this.setEntityType();\n      this.setId();\n      this.setIndex();\n      this.setAuditFieldsForInsert();\n    } else {\n      this.setAuditFieldsForUpdate();\n    }\n  }\n\n  getData() {\n    return this.data;\n  }\n\n  setEntityType() {\n    this.data.entityType = this.data.entityType || this.constructor.name;\n  }\n\n  setId() {\n    this.data.id = this.data.id || (0, _uuid.v4)();\n  }\n\n  setIndex() {\n    this.data.gsi1 = this.data.gsi1 || this.data.parentId;\n    this.data.gsi2 = this.data.gsi2 || null;\n  }\n\n  setAuditFieldsForInsert() {\n    this.data.createdBy = this.user.claims.name;\n    this.data.createdDate = (0, _moment2.default)().unix();\n  }\n\n  setAuditFieldsForUpdate() {\n    this.data.lastUpdatedBy = this.user.claims.name;\n    this.data.lastUpdatedDate = (0, _moment2.default)().unix();\n  }\n\n}\n\nexports.default = BaseModel;\n\n//# sourceURL=webpack://online-course/./models/base-model.js?");

/***/ }),

/***/ "./models/comment.js":
/*!***************************!*\
  !*** ./models/comment.js ***!
  \***************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _baseModel = __webpack_require__(/*! ./base-model */ \"./models/base-model.js\");\n\nvar _baseModel2 = _interopRequireDefault(_baseModel);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass Comment extends _baseModel2.default {\n  setIndex() {\n    this.data.gsi1 = this.data.parentId;\n  }\n\n}\n\nexports.default = Comment;\n\n//# sourceURL=webpack://online-course/./models/comment.js?");

/***/ }),

/***/ "./models/course.js":
/*!**************************!*\
  !*** ./models/course.js ***!
  \**************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _baseModel = __webpack_require__(/*! ./base-model */ \"./models/base-model.js\");\n\nvar _baseModel2 = _interopRequireDefault(_baseModel);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass Course extends _baseModel2.default {\n  setIndex() {\n    this.data.gsi1 = this.data.authorId;\n  }\n\n}\n\nexports.default = Course;\n\n//# sourceURL=webpack://online-course/./models/course.js?");

/***/ }),

/***/ "./models/courseSubscription.js":
/*!**************************************!*\
  !*** ./models/courseSubscription.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _baseModel = __webpack_require__(/*! ./base-model */ \"./models/base-model.js\");\n\nvar _baseModel2 = _interopRequireDefault(_baseModel);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass CourseSubscription extends _baseModel2.default {\n  setIndex() {\n    this.data.gsi1 = this.data.userId;\n    this.data.gsi2 = this.data.courseId;\n  }\n\n}\n\nexports.default = CourseSubscription;\n\n//# sourceURL=webpack://online-course/./models/courseSubscription.js?");

/***/ }),

/***/ "./models/courseVideo.js":
/*!*******************************!*\
  !*** ./models/courseVideo.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\n\nvar _baseModel = __webpack_require__(/*! ./base-model */ \"./models/base-model.js\");\n\nvar _baseModel2 = _interopRequireDefault(_baseModel);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nclass CourseVideo extends _baseModel2.default {\n  setIndex() {\n    this.data.gsi1 = this.data.courseId;\n  }\n\n}\n\nexports.default = CourseVideo;\n\n//# sourceURL=webpack://online-course/./models/courseVideo.js?");

/***/ }),

/***/ "./mutations/functions-registry.js":
/*!*****************************************!*\
  !*** ./mutations/functions-registry.js ***!
  \*****************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\n\nconst {\n  addCourse,\n  addCourseVideo,\n  subscribeCourse,\n  addComment,\n  deleteCourse,\n  deleteCourseVideo\n} = __webpack_require__(/*! ./functions/course */ \"./mutations/functions/course.js\");\n\nmodule.exports = [{\n  name: \"createCourse\",\n  mutationHandler: addCourse\n}, {\n  name: \"createCourseVideo\",\n  mutationHandler: addCourseVideo\n}, {\n  name: \"subscribeCourse\",\n  mutationHandler: subscribeCourse\n}, {\n  name: \"addComments\",\n  mutationHandler: addComment\n}, {\n  name: \"deleteCourse\",\n  mutationHandler: deleteCourse\n}, {\n  name: \"deleteCourseVideo\",\n  mutationHandler: deleteCourseVideo\n}];\n\n//# sourceURL=webpack://online-course/./mutations/functions-registry.js?");

/***/ }),

/***/ "./mutations/functions/course.js":
/*!***************************************!*\
  !*** ./mutations/functions/course.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.addCourse = addCourse;\nexports.addCourseVideo = addCourseVideo;\nexports.deleteCourse = deleteCourse;\nexports.deleteCourseVideo = deleteCourseVideo;\nexports.subscribeCourse = subscribeCourse;\nexports.addComment = addComment;\n\nvar _constants = __webpack_require__(/*! ../../constants */ \"./constants.js\");\n\nvar _course = __webpack_require__(/*! ../../models/course */ \"./models/course.js\");\n\nvar _course2 = _interopRequireDefault(_course);\n\nvar _dynamodbHelper = __webpack_require__(/*! ../../helper/dynamodb-helper */ \"./helper/dynamodb-helper.js\");\n\nvar _dynamodbHelper2 = _interopRequireDefault(_dynamodbHelper);\n\nvar _courseVideo = __webpack_require__(/*! ../../models/courseVideo */ \"./models/courseVideo.js\");\n\nvar _courseVideo2 = _interopRequireDefault(_courseVideo);\n\nvar _courseSubscription = __webpack_require__(/*! ../../models/courseSubscription */ \"./models/courseSubscription.js\");\n\nvar _courseSubscription2 = _interopRequireDefault(_courseSubscription);\n\nvar _comment = __webpack_require__(/*! ../../models/comment */ \"./models/comment.js\");\n\nvar _comment2 = _interopRequireDefault(_comment);\n\nvar _s3Helper = __webpack_require__(/*! ../../helper/s3-helper */ \"./helper/s3-helper.js\");\n\nvar _s3Helper2 = _interopRequireDefault(_s3Helper);\n\nfunction _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }\n\nasync function addCourse(service) {\n  const {\n    user,\n    args\n  } = service;\n  console.log(`addCourse::`, JSON.stringify(service, 0, 2));\n  const course = new _course2.default({ ...args.course,\n    authorId: user.username\n  }, user, _constants.OPERATION.INSERT);\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  await dynamoDBHelper.batchWrite([course.getData()]);\n  return course.getData();\n}\n\nasync function addCourseVideo(service) {\n  const {\n    user,\n    args\n  } = service;\n  console.log(`addCourse::`, JSON.stringify(service, 0, 2));\n  const courseVideo = new _courseVideo2.default(args.courseVideo, user, _constants.OPERATION.INSERT);\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  await dynamoDBHelper.batchWrite([courseVideo.getData()]);\n  return courseVideo.getData();\n}\n\nasync function deleteCourse(service) {\n  const {\n    args: {\n      id\n    }\n  } = service;\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  const [courseVideos, comments, courseSubscription] = await Promise.all([dynamoDBHelper.getEntityByGsi1(_constants.ENTITY_TYPES.COURSE_VIDEO, id), dynamoDBHelper.getEntityByGsi1(_constants.ENTITY_TYPES.COMMENT, id), dynamoDBHelper.getEntityByGsi2(_constants.ENTITY_TYPES.COURSE_SUBSCRIPTION, id)]);\n  const itemsToDelete = [{\n    entityType: _constants.ENTITY_TYPES.COURSE,\n    id\n  }];\n  [...courseVideos, ...comments, ...courseSubscription].map(({\n    id,\n    entityType\n  }) => itemsToDelete.push({\n    id,\n    entityType\n  }));\n  await dynamoDBHelper.batchDelete(itemsToDelete);\n  const s3Helper = new _s3Helper2.default();\n  await s3Helper.deleteObjects(courseVideos.map(video => video.videoUrl));\n  return {\n    entityType: _constants.ENTITY_TYPES.COURSE,\n    id\n  };\n}\n\nasync function deleteCourseVideo(service) {\n  const {\n    args: {\n      id\n    }\n  } = service;\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  const courseVideo = await dynamoDBHelper.getEntityById(_constants.ENTITY_TYPES.COURSE_VIDEO, id);\n  const itemsToDelete = [{\n    entityType: _constants.ENTITY_TYPES.COURSE_VIDEO,\n    id\n  }];\n  await dynamoDBHelper.batchDelete(itemsToDelete);\n  const s3Helper = new _s3Helper2.default();\n  await s3Helper.deleteObjects([courseVideo.videoUrl]);\n  return {\n    entityType: _constants.ENTITY_TYPES.COURSE_VIDEO,\n    id\n  };\n}\n\nasync function subscribeCourse(service) {\n  const {\n    user,\n    args\n  } = service;\n  console.log(`addCourse::`, JSON.stringify(service, 0, 2));\n  const courseSubscription = new _courseSubscription2.default({\n    courseId: args.courseId,\n    userId: user.username\n  }, user, _constants.OPERATION.INSERT);\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  await dynamoDBHelper.batchWrite([courseSubscription.getData()]);\n  return courseSubscription.getData();\n}\n\nasync function addComment(service) {\n  const {\n    user,\n    args\n  } = service;\n  console.log(`addCourse::`, JSON.stringify(service, 0, 2));\n  const comment = new _comment2.default({ ...args,\n    userId: user.username\n  }, user, _constants.OPERATION.INSERT);\n  const dynamoDBHelper = new _dynamodbHelper2.default();\n  await dynamoDBHelper.batchWrite([comment.getData()]);\n  return comment.getData();\n}\n\n//# sourceURL=webpack://online-course/./mutations/functions/course.js?");

/***/ }),

/***/ "aws-sdk":
/*!**************************!*\
  !*** external "aws-sdk" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("aws-sdk");;

/***/ }),

/***/ "moment":
/*!*************************!*\
  !*** external "moment" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("moment");;

/***/ }),

/***/ "uuid":
/*!***********************!*\
  !*** external "uuid" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("uuid");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./lambdas/mutations.js");
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;